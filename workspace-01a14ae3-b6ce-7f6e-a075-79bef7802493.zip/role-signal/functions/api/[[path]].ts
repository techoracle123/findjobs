import { app } from '../../src/worker'
import type { AppBindings } from '../../src/worker'

export const onRequest: PagesFunction<AppBindings> = ({ request, env }) => app.fetch(request, env)
