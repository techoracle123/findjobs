import { useCallback, useEffect, useMemo, useState, type ChangeEvent, type FormEvent } from 'react'
import {
  ArrowDownUp, ArrowRight, ArrowUpRight, Bell, Bookmark, BriefcaseBusiness,
  Check, CheckCircle2, ChevronDown, ChevronRight, CircleAlert, CircleHelp, Clock3,
  FileText, LayoutDashboard, ListChecks, LoaderCircle, LockKeyhole,
  MapPin, Menu, Monitor, Search, Send, ShieldCheck, Sparkles, UserRound,
  X, Upload, WalletCards,
} from 'lucide-react'
import { COUNTRY_OPTIONS } from './shared/countries'
import { DEMO_JOBS, type CandidateProfile, type Job } from './shared/jobs'
import { convertSalary, matchJob } from './shared/matching'
import {
  loadAlerts, loadApplications, loadDemoAccess, loadProfile, loadSaved,
  saveAlerts, saveApplications, saveDemoAccess, saveProfile, saveSaved,
  type AlertPreferences, type ApplicationState,
} from './shared/storage'

const CURRENCY_OPTIONS = ['USD', 'EUR', 'GBP', 'NGN', 'CAD', 'AUD', 'INR', 'JPY', 'SGD', 'ZAR', 'KES', 'GHS', 'AED', 'BRL', 'CHF', 'MXN']
const ROLE_FAMILIES = ['Software engineering', 'Data & AI', 'Cloud & platform', 'Cybersecurity', 'Quality engineering', 'Product & design', 'IT & technical operations', 'Technical sales & writing']
const PAGE_LABELS: Record<Page, string> = {
  discover: 'Discover opportunities', saved: 'Saved roles', applications: 'Application tracker',
  profile: 'Skill Passport', alerts: 'Telegram alerts', account: 'Plan & access',
}
type Page = 'discover' | 'saved' | 'applications' | 'profile' | 'alerts' | 'account'
type RateResponse = { rates: Record<string, number>; asOf: string | null; source: string; isIndicative: boolean }
type ParsedDraft = { displayName: string; skills: string[]; targetRoles: string[]; summary: string; extractionMode: string; confidence: string }
type Toast = { message: string; type: 'success' | 'info' | 'error' } | null

const navItems: Array<{ id: Page; label: string; icon: typeof LayoutDashboard }> = [
  { id: 'discover', label: 'Discover', icon: LayoutDashboard },
  { id: 'saved', label: 'Saved roles', icon: Bookmark },
  { id: 'applications', label: 'Applications', icon: ListChecks },
  { id: 'profile', label: 'Skill Passport', icon: UserRound },
  { id: 'alerts', label: 'Alerts', icon: Bell },
]

const CURRENCY_LOCALE: Record<string, string> = {
  USD: 'en-US', EUR: 'en-IE', GBP: 'en-GB', NGN: 'en-NG', CAD: 'en-CA', AUD: 'en-AU',
  INR: 'en-IN', JPY: 'ja-JP', SGD: 'en-SG', ZAR: 'en-ZA', KES: 'en-KE', GHS: 'en-GH',
  AED: 'en-AE', BRL: 'pt-BR', CHF: 'de-CH', MXN: 'es-MX',
}

function currencyFormat(amount: number, currency: string) {
  try {
    return new Intl.NumberFormat(CURRENCY_LOCALE[currency] ?? 'en-US', { style: 'currency', currency, maximumFractionDigits: 0 }).format(amount)
  } catch { return `${currency} ${Math.round(amount).toLocaleString()}` }
}

function salaryLabel(job: Job, currency: string, rates: Record<string, number>, includeOriginal = false) {
  if (job.salaryMin == null || !job.salaryCurrency) return 'Salary not disclosed'
  const min = convertSalary(job.salaryMin, job.salaryCurrency, currency, rates)
  const max = job.salaryMax == null ? null : convertSalary(job.salaryMax, job.salaryCurrency, currency, rates)
  if (min == null) {
    const original = `${currencyFormat(job.salaryMin, job.salaryCurrency)}${job.salaryMax ? `–${currencyFormat(job.salaryMax, job.salaryCurrency)}` : '+'}`
    return `${original} / ${job.salaryPeriod ?? 'period'}`
  }
  const converted = `${currencyFormat(min, currency)}${max == null ? '+' : `–${currencyFormat(max, currency)}`}`
  const original = includeOriginal && job.salaryCurrency !== currency
    ? ` · source ${currencyFormat(job.salaryMin, job.salaryCurrency)}${job.salaryMax ? `–${currencyFormat(job.salaryMax, job.salaryCurrency)}` : '+'}`
    : ''
  return `≈ ${converted}${original} / ${job.salaryPeriod ?? 'period'}`
}

function relativeDate(value: string | null) {
  if (!value) return 'Date not provided'
  const diff = Date.now() - new Date(value).getTime()
  if (!Number.isFinite(diff)) return 'Date not provided'
  const days = Math.max(0, Math.floor(diff / 86_400_000))
  if (days === 0) return 'Today'
  if (days === 1) return '1 day ago'
  return `${days} days ago`
}

function App() {
  const [page, setPage] = useState<Page>('discover')
  const [jobs, setJobs] = useState<Job[]>(DEMO_JOBS)
  const [dataMode, setDataMode] = useState<'demo' | 'database'>('demo')
  const [loadingJobs, setLoadingJobs] = useState(true)
  const [apiAvailable, setApiAvailable] = useState(false)
  const [aiAvailable, setAiAvailable] = useState(false)
  const [telegramConfigured, setTelegramConfigured] = useState(false)
  const [botUsername, setBotUsername] = useState<string | null>(null)
  const [rates, setRates] = useState<Record<string, number>>({ USD: 1 })
  const [ratesDate, setRatesDate] = useState<string | null>(null)
  const [ratesAvailable, setRatesAvailable] = useState(false)
  const [profile, setProfile] = useState<CandidateProfile>(() => loadProfile())
  const [savedJobs, setSavedJobs] = useState<string[]>(() => loadSaved())
  const [applications, setApplications] = useState<ApplicationState>(() => loadApplications())
  const [alerts, setAlerts] = useState<AlertPreferences>(() => loadAlerts())
  const [demoAccess, setDemoAccess] = useState(() => loadDemoAccess())
  const [query, setQuery] = useState('')
  const [familyFilter, setFamilyFilter] = useState('')
  const [workFilter, setWorkFilter] = useState('')
  const [eligibilityFilter, setEligibilityFilter] = useState('')
  const [sortMode, setSortMode] = useState('best')
  const [selectedJobId, setSelectedJobId] = useState('demo-platform')
  const [profileDraft, setProfileDraft] = useState<CandidateProfile>(() => loadProfile())
  const [cvBusy, setCvBusy] = useState(false)
  const [cvError, setCvError] = useState('')
  const [cvDraft, setCvDraft] = useState<ParsedDraft | null>(null)
  const [cvFileName, setCvFileName] = useState('')
  const [toast, setToast] = useState<Toast>(null)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const notify = useCallback((message: string, type: 'success' | 'info' | 'error' = 'info') => {
    setToast({ message, type })
    window.setTimeout(() => setToast(null), 3600)
  }, [])

  useEffect(() => {
    saveProfile(profile)
  }, [profile])
  useEffect(() => { saveSaved(savedJobs) }, [savedJobs])
  useEffect(() => { saveApplications(applications) }, [applications])
  useEffect(() => { saveAlerts(alerts) }, [alerts])
  useEffect(() => { saveDemoAccess(demoAccess) }, [demoAccess])

  useEffect(() => {
    const handleSearchShortcut = (event: KeyboardEvent) => {
      if (event.key !== '/' || event.metaKey || event.ctrlKey || event.altKey) return
      const target = event.target instanceof HTMLElement ? event.target : null
      if (target?.closest('input, textarea, select, [contenteditable="true"]')) return
      const search = document.querySelector<HTMLInputElement>('.searchbox input')
      if (!search) return
      event.preventDefault()
      search.focus()
    }
    window.addEventListener('keydown', handleSearchShortcut)
    return () => window.removeEventListener('keydown', handleSearchShortcut)
  }, [page])

  useEffect(() => {
    let cancelled = false
    async function loadRemoteData() {
      try {
        const response = await fetch('/api/jobs')
        if (response.ok) {
          const payload = await response.json() as { jobs?: Job[]; dataMode?: 'demo' | 'database' }
          if (!cancelled && payload.jobs?.length) {
            setJobs(payload.jobs)
            setDataMode(payload.dataMode ?? 'demo')
            setApiAvailable(true)
          }
        }
      } catch { /* The front end remains usable with clearly labelled local preview records. */ }
      try {
        const health = await fetch('/api/health').then((response) => response.json()) as { aiBinding?: boolean; telegramConfigured?: boolean }
        if (!cancelled) {
          setApiAvailable(true)
          setAiAvailable(Boolean(health.aiBinding))
          setTelegramConfigured(Boolean(health.telegramConfigured))
        }
      } catch { /* local preview */ }
      try {
        const result = await fetch('/api/currency-rates?base=USD').then((response) => response.ok ? response.json() : null) as RateResponse | null
        if (!cancelled && result?.rates) {
          setRates(result.rates)
          setRatesDate(result.asOf)
          setRatesAvailable(true)
        }
      } catch { /* original currency remains visible if conversion service is unavailable */ }
      try {
        const status = await fetch('/api/telegram/status').then((response) => response.json()) as { configured?: boolean; botUsername?: string | null }
        if (!cancelled) {
          setTelegramConfigured(Boolean(status.configured))
          setBotUsername(status.botUsername ?? null)
        }
      } catch { /* status is reflected as not configured */ }
      if (!cancelled) setLoadingJobs(false)
    }
    void loadRemoteData()
    return () => { cancelled = true }
  }, [])

  const profileComplete = profile.skills.length > 0 && profile.workCountries.length > 0
  const families = useMemo(() => Array.from(new Set(jobs.map((job) => job.family))).sort(), [jobs])

  const visibleJobs = useMemo(() => {
    let result = [...jobs]
    if (page === 'saved') result = result.filter((job) => savedJobs.includes(job.id))
    if (page === 'applications') result = result.filter((job) => Boolean(applications[job.id]))
    if (query.trim()) {
      const needle = query.trim().toLowerCase()
      result = result.filter((job) => [job.title, job.employer, job.location, job.family, job.description, ...job.requiredSkills, ...job.preferredSkills].join(' ').toLowerCase().includes(needle))
    }
    if (familyFilter) result = result.filter((job) => job.family === familyFilter)
    if (workFilter) result = result.filter((job) => job.workMode === workFilter)
    if (eligibilityFilter) result = result.filter((job) => matchJob(job, profile).eligibility === eligibilityFilter)
    if (sortMode === 'newest') result.sort((a, b) => Date.parse(b.postedAt) - Date.parse(a.postedAt))
    else if (sortMode === 'salary') {
      const topSalary = (job: Job) => {
        if (!job.salaryCurrency) return null
        const amount = job.salaryMax ?? job.salaryMin
        return amount == null ? null : convertSalary(amount, job.salaryCurrency, profile.preferredCurrency || 'USD', rates)
      }
      result.sort((a, b) => {
        const salaryA = topSalary(a)
        const salaryB = topSalary(b)
        if (salaryA == null) return salaryB == null ? 0 : 1
        if (salaryB == null) return -1
        return salaryB - salaryA
      })
    } else {
      const eligibilityOrder = { eligible: 0, unknown: 1, restricted: 2 }
      result.sort((a, b) => {
        const matchA = matchJob(a, profile)
        const matchB = matchJob(b, profile)
        return eligibilityOrder[matchA.eligibility] - eligibilityOrder[matchB.eligibility]
          || (matchB.score ?? -1) - (matchA.score ?? -1)
          || Date.parse(b.postedAt) - Date.parse(a.postedAt)
      })
    }
    return result
  }, [jobs, page, savedJobs, applications, query, familyFilter, workFilter, eligibilityFilter, sortMode, profile, rates])

  const selectedJob = visibleJobs.find((job) => job.id === selectedJobId) ?? visibleJobs[0] ?? null

  const toggleSaved = (id: string) => {
    setSavedJobs((current) => current.includes(id) ? current.filter((savedId) => savedId !== id) : [...current, id])
    notify(savedJobs.includes(id) ? 'Removed from saved roles.' : 'Saved to your list.', 'success')
  }

  const updateApplication = (jobId: string, status: string) => {
    setApplications((current) => ({
      ...current,
      [jobId]: { status, note: current[jobId]?.note ?? '', updatedAt: new Date().toISOString() },
    }))
    notify(status === 'applied' ? 'Application marked as submitted.' : 'Application tracker updated.', 'success')
  }

  const navigate = (next: Page) => {
    setPage(next)
    setMobileMenuOpen(false)
    setSelectedJobId('')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const handleProfileSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setProfile(profileDraft)
    notify('Your Skill Passport is saved on this device.', 'success')
  }

  const toggleWorkCountry = (country: string) => {
    setProfileDraft((current) => ({
      ...current,
      workCountries: current.workCountries.includes(country)
        ? current.workCountries.filter((item) => item !== country)
        : [...current.workCountries, country],
    }))
  }

  const handleCvUpload = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return
    setCvError('')
    setCvDraft(null)
    setCvBusy(true)
    setCvFileName(file.name)
    try {
      const { extractCVText } = await import('./shared/cv')
      const extracted = await extractCVText(file)
      if (extracted.text.trim().length < 30) throw new Error('Very little text was found. This may be a scanned or image-only CV; try a text-based PDF or DOCX.')
      const response = await fetch('/api/cv/parse', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ text: extracted.text, filename: file.name }),
      })
      if (!response.ok) {
        const issue = await response.json().catch(() => ({})) as { error?: string }
        throw new Error(issue.error ?? 'CV parsing could not complete.')
      }
      const result = await response.json() as { draft: ParsedDraft; notice?: string }
      setCvDraft(result.draft)
      notify(result.notice ?? 'CV extracted. Review every suggestion before saving.', 'info')
    } catch (error) {
      setCvError(error instanceof Error ? error.message : 'Could not read this file. Try PDF, DOCX or TXT.')
    } finally {
      setCvBusy(false)
      event.target.value = ''
    }
  }

  const applyCvDraft = () => {
    if (!cvDraft) return
    const mergedSkills = Array.from(new Set([...profileDraft.skills, ...cvDraft.skills].map((skill) => skill.trim()).filter(Boolean)))
    const mergedRoles = Array.from(new Set([...profileDraft.targetRoles, ...cvDraft.targetRoles].map((role) => role.trim()).filter(Boolean)))
    setProfileDraft((current) => ({ ...current, displayName: current.displayName || cvDraft.displayName, skills: mergedSkills, targetRoles: mergedRoles }))
    setCvDraft(null)
    setCvError('')
    notify('Draft details added to the form. Save your Skill Passport to confirm them.', 'success')
  }

  const updateAlertPref = <K extends keyof AlertPreferences>(key: K, value: AlertPreferences[K]) => setAlerts((current) => ({ ...current, [key]: value }))

  const handleCurrencyChange = (currency: string) => {
    setProfile((current) => ({ ...current, preferredCurrency: currency }))
    setProfileDraft((current) => ({ ...current, preferredCurrency: currency }))
    if (!ratesAvailable) notify('Reference rates are unavailable. Salaries remain in the employer’s stated currency.', 'info')
  }

  const pageTitle = PAGE_LABELS[page]
  const savedCount = savedJobs.length
  const appliedCount = Object.values(applications).filter((item) => ['applied', 'interview', 'offer', 'rejected', 'withdrawn'].includes(item.status)).length

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileMenuOpen ? 'sidebar-open' : ''}`} aria-label="Main navigation">
        <div className="brand-lockup">
          <div className="brand-mark" aria-hidden="true"><span /><span /><span /></div>
          <div><strong>Role Signal</strong><small>TECH OPPORTUNITY DESK</small></div>
          <button className="icon-button close-mobile" aria-label="Close navigation" onClick={() => setMobileMenuOpen(false)}><X size={18} /></button>
        </div>
        <div className="workspace-label">WORKSPACE</div>
        <nav className="primary-nav">
          {navItems.map(({ id, label, icon: Icon }) => (
            <button key={id} className={`nav-item ${page === id ? 'is-current' : ''}`} onClick={() => navigate(id)} aria-current={page === id ? 'page' : undefined}>
              <Icon size={18} strokeWidth={1.8} />
              <span>{label}</span>
              {id === 'saved' && savedCount > 0 && <span className="nav-count">{savedCount}</span>}
              {id === 'applications' && appliedCount > 0 && <span className="nav-count">{appliedCount}</span>}
            </button>
          ))}
        </nav>
        <div className="sidebar-spacer" />
        <div className="sidebar-note">
          <div className="sidebar-note-icon"><ShieldCheck size={16} /></div>
          <div><strong>Evidence before AI</strong><p>Unknown details stay unknown. Job facts keep their source.</p></div>
        </div>
        <button className={`account-link ${page === 'account' ? 'is-current' : ''}`} onClick={() => navigate('account')}>
          <WalletCards size={18} /><span>Plan & access</span><ChevronRight size={16} className="account-chevron" />
        </button>
        <div className="sidebar-footer"><span className="status-dot" /> Preview build · sample data</div>
      </aside>

      {mobileMenuOpen && <button className="mobile-scrim" aria-label="Close navigation" onClick={() => setMobileMenuOpen(false)} />}

      <main className="main-column">
        <header className="topbar">
          <button className="icon-button menu-trigger" aria-label="Open navigation" onClick={() => setMobileMenuOpen(true)}><Menu size={20} /></button>
          <div className="breadcrumb"><span>Opportunity desk</span><ChevronRight size={14} /><strong>{pageTitle}</strong></div>
          <div className="topbar-right">
            <label className="currency-control" htmlFor="global-currency"><span>SHOW IN</span><select id="global-currency" value={profile.preferredCurrency || 'USD'} onChange={(event) => void handleCurrencyChange(event.target.value)} aria-label="Preferred salary display currency">{CURRENCY_OPTIONS.map((currency) => <option key={currency} value={currency}>{currency}</option>)}</select><ChevronDown size={13} /></label>
            <button className="avatar-button" onClick={() => navigate('profile')} aria-label="Open Skill Passport">{profile.displayName ? profile.displayName.trim().slice(0, 1).toUpperCase() : <UserRound size={17} />}</button>
          </div>
        </header>

        <div className="content-wrap">
          <div className="preview-banner" role="status">
            <div className="preview-banner-icon"><CircleAlert size={17} /></div>
            <div><strong>Preview mode</strong><span>{dataMode === 'demo' ? 'All listings shown are fictional sample records—not live jobs.' : 'Database mode. Confirm source and verification status before acting.'}</span></div>
            <span className="preview-banner-end">{apiAvailable ? 'API connected' : 'Local preview'}</span>
          </div>

          {page === 'discover' || page === 'saved' || page === 'applications' ? (
            <>
              <div className="page-heading-row">
                <div>
                  <p className="eyebrow">{page === 'discover' ? 'GLOBAL TECH ROLES' : page === 'saved' ? 'YOUR SHORTLIST' : 'YOUR SEARCH, IN MOTION'}</p>
                  <h1>{pageTitle}</h1>
                  <p className="page-intro">{page === 'discover' ? 'Find roles by skills, work eligibility and the details that matter to you.' : page === 'saved' ? 'Keep promising roles together and come back when you are ready.' : 'Track your next step without losing the details.'}</p>
                </div>
                {page === 'discover' && <div className="profile-progress"><div className="progress-ring"><span>{profileComplete ? '✓' : '0%'}</span></div><div><span>Skill Passport</span><button onClick={() => navigate('profile')}>{profileComplete ? 'Edit profile' : 'Add your skills'} <ArrowRight size={13} /></button></div></div>}
              </div>

              {page !== 'applications' && (
                <div className="search-toolbar">
                  <label className="searchbox"><Search size={18} /><span className="visually-hidden">Search roles, skills or employers</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search roles, skills or employers" aria-keyshortcuts="/" /><kbd>/</kbd></label>
                  <label className="filter-control"><span className="visually-hidden">Filter by job family</span><select value={familyFilter} onChange={(event) => setFamilyFilter(event.target.value)}><option value="">All disciplines</option>{families.map((family) => <option key={family}>{family}</option>)}</select><ChevronDown size={14} /></label>
                  <label className="filter-control mode-filter"><span className="visually-hidden">Filter by work mode</span><select value={workFilter} onChange={(event) => setWorkFilter(event.target.value)}><option value="">Any work mode</option><option value="remote">Remote</option><option value="hybrid">Hybrid</option><option value="onsite">On-site</option></select><ChevronDown size={14} /></label>
                  <label className="filter-control eligibility-filter"><span className="visually-hidden">Filter by eligibility</span><select value={eligibilityFilter} onChange={(event) => setEligibilityFilter(event.target.value)}><option value="">Any eligibility</option><option value="eligible">Eligible based on profile</option><option value="unknown">Eligibility unknown</option><option value="restricted">Restricted</option></select><ChevronDown size={14} /></label>
                  <label className="sort-control"><ArrowDownUp size={15} /><span className="visually-hidden">Sort jobs</span><select value={sortMode} onChange={(event) => setSortMode(event.target.value)}><option value="best">Best fit</option><option value="newest">Newest</option><option value="salary">Salary high–low</option></select><ChevronDown size={13} /></label>
                </div>
              )}

              <div className="results-meta">
                <div><strong>{visibleJobs.length}</strong> {visibleJobs.length === 1 ? 'sample opportunity' : 'sample opportunities'} <span className="meta-divider">·</span> <span>global preview coverage</span></div>
                <div className="rate-meta">{ratesAvailable && ratesDate ? <><span>Indicative FX · {ratesDate}</span><span className="help-tip" role="img" aria-label="Daily reference rates; not a live trading quote."><CircleHelp size={14} /></span></> : <><span>Showing employer currency where FX is unavailable</span><span className="help-tip" role="img" aria-label="Salary conversions use daily reference rates when available."><CircleHelp size={14} /></span></>}{sortMode === 'best' && <span className="best-fit-note">Eligible → unknown → restricted, then match score; newer breaks ties</span>}{sortMode === 'salary' && <span className="salary-sort-note">Top values in {profile.preferredCurrency}; pay periods not normalized</span>}</div>
              </div>

              {loadingJobs && <div className="loading-line"><LoaderCircle size={16} className="spin" /> Loading opportunities…</div>}
              {!loadingJobs && visibleJobs.length === 0 ? (
                <EmptyState icon={page === 'saved' ? Bookmark : Search} title={page === 'saved' ? 'No saved roles yet' : 'No roles match those filters'} body={page === 'saved' ? 'Save a role from Discover to keep it here.' : 'Try a different skill, discipline or location filter.'} action={page === 'saved' ? 'Browse roles' : 'Clear filters'} onAction={() => page === 'saved' ? navigate('discover') : (setQuery(''), setFamilyFilter(''), setWorkFilter(''), setEligibilityFilter(''))} />
              ) : (
                <div className={`opportunity-layout ${selectedJob ? 'has-selection' : ''}`}>
                  <section className="job-list" aria-label="Opportunity results">
                    {visibleJobs.map((job) => <JobRow key={job.id} job={job} profile={profile} selected={selectedJob?.id === job.id} saved={savedJobs.includes(job.id)} currency={profile.preferredCurrency || 'USD'} rates={rates} applications={applications} onSelect={() => { setSelectedJobId(job.id); if (window.innerWidth < 900) window.setTimeout(() => document.getElementById('job-detail')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60) }} onSave={() => toggleSaved(job.id)} />)}
                  </section>
                  {selectedJob && <JobDetail job={selectedJob} profile={profile} saved={savedJobs.includes(selectedJob.id)} currency={profile.preferredCurrency || 'USD'} rates={rates} ratesDate={ratesDate} applications={applications} onSave={() => toggleSaved(selectedJob.id)} onTrack={(status) => updateApplication(selectedJob.id, status)} onEditProfile={() => navigate('profile')} />}
                </div>
              )}
            </>
          ) : null}

          {page === 'profile' && <ProfilePage profile={profileDraft} onChange={setProfileDraft} onSave={handleProfileSubmit} onFile={handleCvUpload} cvBusy={cvBusy} cvError={cvError} cvDraft={cvDraft} cvFileName={cvFileName} aiAvailable={aiAvailable} onApplyCv={applyCvDraft} onDiscardCv={() => setCvDraft(null)} onDraftChange={setCvDraft} onCountryToggle={toggleWorkCountry} />}
          {page === 'alerts' && <AlertsPage preferences={alerts} onChange={updateAlertPref} telegramConfigured={telegramConfigured} botUsername={botUsername} onSave={() => notify('Alert preferences saved on this device. Live delivery needs bot setup and a linked account.', 'success')} />}
          {page === 'account' && <AccountPage demoAccess={demoAccess} onToggleDemo={() => { setDemoAccess((value) => !value); notify(!demoAccess ? 'Preview access enabled on this device; no payment was taken.' : 'Preview access disabled.', 'info') }} />}
        </div>
      </main>

      <MobileNav page={page} onNavigate={navigate} />
      {toast && <div className={`toast toast-${toast.type}`} role="status"><span className="toast-symbol">{toast.type === 'success' ? <CheckCircle2 size={17} /> : toast.type === 'error' ? <CircleAlert size={17} /> : <CircleHelp size={17} />}</span>{toast.message}<button className="toast-close" aria-label="Dismiss notification" onClick={() => setToast(null)}><X size={15} /></button></div>}
    </div>
  )
}

function JobRow({ job, profile, selected, saved, currency, rates, applications, onSelect, onSave }: {
  job: Job; profile: CandidateProfile; selected: boolean; saved: boolean; currency: string; rates: Record<string, number>;
  applications: ApplicationState; onSelect: () => void; onSave: () => void;
}) {
  const result = matchJob(job, profile)
  const application = applications[job.id]
  return (
    <article className={`job-row ${selected ? 'row-selected' : ''}`}>
      <button className="job-main-button" onClick={onSelect} aria-label={`View ${job.title} at ${job.employer}`}>
        <div className="job-row-topline"><span className={`job-family family-${familySlug(job.family)}`}>{job.family}</span>{job.isDemo && <span className="demo-tag">DEMO</span>}{application && <span className="application-tag">{application.status}</span>}</div>
        <h2>{job.title}</h2>
        <div className="job-employer">{job.employer}</div>
        <div className="job-facts"><span><MapPin size={14} />{job.location}</span><span><BriefcaseBusiness size={14} />{job.employment}</span><span><Clock3 size={14} />{relativeDate(job.postedAt)}</span></div>
        <div className="job-row-bottom"><div className="skill-snippets">{job.requiredSkills.slice(0, 3).map((skill) => <span key={skill}>{skill}</span>)}{job.requiredSkills.length > 3 && <span>+{job.requiredSkills.length - 3}</span>}</div><div className="row-pay">{salaryLabel(job, currency, rates)}</div></div>
      </button>
      <div className="job-row-aside">
        <button className={`bookmark-button ${saved ? 'is-saved' : ''}`} onClick={onSave} aria-label={saved ? 'Remove saved role' : 'Save role'} aria-pressed={saved}>{saved ? <Bookmark size={17} fill="currentColor" /> : <Bookmark size={17} />}</button>
        <div className={`match-indicator ${result.score !== null && result.score >= 75 ? 'match-high' : result.score === null ? 'match-pending' : 'match-standard'}`}>
          {result.score === null ? <><span>—</span><small>add skills</small></> : <><span>{result.score}%</span><small>match score</small></>}
        </div>
      </div>
    </article>
  )
}

function JobDetail({ job, profile, saved, currency, rates, ratesDate, applications, onSave, onTrack, onEditProfile }: {
  job: Job; profile: CandidateProfile; saved: boolean; currency: string; rates: Record<string, number>; ratesDate: string | null; applications: ApplicationState;
  onSave: () => void; onTrack: (status: string) => void; onEditProfile: () => void;
}) {
  const result = matchJob(job, profile)
  const appState = applications[job.id]
  const convertedSalary = job.salaryMin == null || !job.salaryCurrency ? null : convertSalary(job.salaryMin, job.salaryCurrency, currency, rates)
  return (
    <aside className="job-detail" id="job-detail" aria-label="Selected job details">
      <div className="detail-scroll">
        <div className="detail-topline"><span className="source-lockup"><span className="source-mark">R</span> {job.source}</span><button className={`icon-button detail-save ${saved ? 'is-saved' : ''}`} aria-label={saved ? 'Remove saved role' : 'Save role'} onClick={onSave}><Bookmark size={17} fill={saved ? 'currentColor' : 'none'} /></button></div>
        <div className="detail-title-block"><div className="detail-tags"><span className={`job-family family-${familySlug(job.family)}`}>{job.family}</span>{job.isDemo && <span className="demo-tag">DEMO RECORD</span>}</div><h2>{job.title}</h2><p>{job.employer}</p></div>
        {job.isDemo && <div className="detail-demo-note"><CircleAlert size={16} /><span>Fictional preview content. There is no real employer or application link.</span></div>}
        <div className="detail-facts-grid">
          <DetailFact icon={MapPin} label="Location" value={job.location} />
          <DetailFact icon={Monitor} label="Work mode" value={capitalize(job.workMode)} />
          <DetailFact icon={BriefcaseBusiness} label="Employment" value={job.employment} />
          <DetailFact icon={Clock3} label="Posted" value={relativeDate(job.postedAt)} />
        </div>
        <section className="fit-section">
          <div className="section-label-row"><h3>Fit & eligibility</h3><span className="fact-source">Evidence-led</span></div>
          <div className="fit-score-row"><div className="fit-score"><strong>{result.score === null ? '—' : `${result.score}%`}</strong><span>match score</span></div><div className={`eligibility-status eligibility-${result.eligibility}`}><span className="status-mark" />{result.eligibility === 'eligible' ? 'Eligible based on profile' : result.eligibility === 'restricted' ? 'Location restriction' : 'Eligibility unknown'}</div></div>
          <p className="fit-method-note">Weights: required skills 48%, useful skills 14%, role 18%, seniority 10%, work mode 10%. Missing facts are neutral; eligibility is separate.</p>
          <p className="eligibility-copy">{result.eligibilityReason}</p>
          {result.score === null ? <button className="inline-link" onClick={onEditProfile}>Add skills for a match explanation <ArrowRight size={14} /></button> : <ul className="reason-list">{result.reasons.slice(0, 3).map((reason) => <li key={reason}><Check size={14} />{reason}</li>)}</ul>}
          {result.missingRequired.length > 0 && <div className="gap-list"><span>Listed skills not in your profile</span><div>{result.missingRequired.slice(0, 5).map((skill) => <em key={skill}>{skill}</em>)}</div></div>}
        </section>
        <section className="detail-section"><div className="section-label-row"><h3>Compensation</h3><span className="help-tip" role="img" aria-label="Salary data is source-provided; converted amounts are indicative."><CircleHelp size={15} /></span></div><p className="salary-large">{salaryLabel(job, currency, rates, true)}</p>{job.salaryMin != null && job.salaryCurrency !== currency && <small className="fx-note">{convertedSalary == null ? 'Reference rate unavailable; the source currency is shown without conversion.' : `Indicative daily reference conversion${ratesDate ? ` as of ${ratesDate}` : ''}; the original source amount is also shown. This is not a live trading quote.`}</small>}</section>
        <section className="detail-section"><div className="section-label-row"><h3>What the listing says</h3></div><p className="job-description">{job.description}</p></section>
        <section className="detail-section"><h3>Required skills</h3><div className="skill-cloud">{job.requiredSkills.map((skill) => <span key={skill} className={result.matchedSkills.includes(skill) ? 'skill-matched' : ''}>{result.matchedSkills.includes(skill) && <Check size={12} />}{skill}</span>)}</div>{job.preferredSkills.length > 0 && <><h4>Also listed as useful</h4><div className="skill-cloud skill-cloud-muted">{job.preferredSkills.map((skill) => <span key={skill}>{skill}</span>)}</div></>}</section>
        <section className="detail-section source-detail"><div className="section-label-row"><h3>Source & freshness</h3><ShieldCheck size={15} /></div><div className="source-row"><span>Source</span><strong>{job.source}</strong></div><div className="source-row"><span>First seen</span><strong>{relativeDate(job.firstSeenAt)}</strong></div><div className="source-row"><span>Last checked</span><strong>{job.lastVerifiedAt ? relativeDate(job.lastVerifiedAt) : 'Not verified'}</strong></div><div className="source-row"><span>Eligibility source</span><strong>{job.eligibility === 'unknown' ? 'Not stated' : 'Listing metadata'}</strong></div></section>
        <div className="detail-actions"><button className="button-secondary" onClick={onSave}>{saved ? <Bookmark size={16} fill="currentColor" /> : <Bookmark size={16} />}{saved ? 'Saved' : 'Save role'}</button><button className="button-primary" onClick={() => onTrack(appState?.status === 'applied' ? 'interview' : 'applied')}><ListChecks size={16} />{appState?.status === 'applied' ? 'Update application' : 'Track application'}</button></div>
        {job.isDemo ? <p className="detail-action-note">Application tracking works in this preview. Applying to the example listing does not contact an employer.</p> : job.sourceUrl ? <a className="external-apply" href={job.sourceUrl} target="_blank" rel="noreferrer">Open employer application <ArrowUpRight size={15} /></a> : <p className="detail-action-note">No verified application link is available.</p>}
      </div>
    </aside>
  )
}

function DetailFact({ icon: Icon, label, value }: { icon: typeof MapPin; label: string; value: string }) {
  return <div className="detail-fact"><Icon size={15} /><span><small>{label}</small><strong>{value}</strong></span></div>
}

function ProfilePage({ profile, onChange, onSave, onFile, cvBusy, cvError, cvDraft, cvFileName, aiAvailable, onApplyCv, onDiscardCv, onDraftChange, onCountryToggle }: {
  profile: CandidateProfile; onChange: (value: CandidateProfile) => void; onSave: (event: FormEvent<HTMLFormElement>) => void;
  onFile: (event: ChangeEvent<HTMLInputElement>) => void; cvBusy: boolean; cvError: string; cvDraft: ParsedDraft | null; cvFileName: string;
  aiAvailable: boolean; onApplyCv: () => void; onDiscardCv: () => void; onDraftChange: (value: ParsedDraft | null) => void; onCountryToggle: (country: string) => void;
}) {
  const skillText = profile.skills.join(', ')
  const [countryQuery, setCountryQuery] = useState('')
  const normalizedCountryQuery = countryQuery.trim().toLowerCase()
  const matchingCountries = normalizedCountryQuery
    ? COUNTRY_OPTIONS.filter(([code, name]) => code.toLowerCase().includes(normalizedCountryQuery) || name.toLowerCase().includes(normalizedCountryQuery))
    : []
  const countriesToShow = matchingCountries.slice(0, 12)
  const selectedCountries = COUNTRY_OPTIONS.filter(([code]) => profile.workCountries.includes(code))
  return (
    <div className="subpage profile-page">
      <div className="page-heading-row compact-heading"><div><p className="eyebrow">YOUR SKILLS, ON YOUR TERMS</p><h1>Skill Passport</h1><p className="page-intro">Give matching enough context to find roles you can actually pursue. You control what gets saved.</p></div><div className="passport-progress"><span className="progress-dot" /> Local preview profile</div></div>
      <form className="profile-form" onSubmit={onSave}>
        <section className="form-section"><div className="form-section-heading"><div className="step-number">01</div><div><h2>Professional profile</h2><p>These details help organise your opportunity feed.</p></div></div>
          <label className="field profile-display-name"><span>Display name</span><input value={profile.displayName} onChange={(event) => onChange({ ...profile, displayName: event.target.value })} placeholder="How should we address you?" autoComplete="name" maxLength={80} /></label>
        </section>
        <section className="form-section"><div className="form-section-heading"><div className="step-number">02</div><div><h2>Skills & target roles</h2><p>Keep skills specific. Related tools are not automatically treated as equivalent.</p></div></div>
          <label className="field"><span>Skills <small>Separate with commas</small></span><textarea rows={3} value={skillText} onChange={(event) => onChange({ ...profile, skills: event.target.value.split(',').map((item) => item.trim()).filter(Boolean) })} placeholder="e.g. SQL, Linux, Figma, incident response" /></label>
          <div className="field"><span>Target role families <small>Select all that interest you</small></span><div className="role-family-grid">{ROLE_FAMILIES.map((family) => <label key={family} className={`role-family-check ${profile.targetRoles.includes(family) ? 'role-family-checked' : ''}`}><input type="checkbox" checked={profile.targetRoles.includes(family)} onChange={() => onChange({ ...profile, targetRoles: profile.targetRoles.includes(family) ? profile.targetRoles.filter((item) => item !== family) : [...profile.targetRoles, family] })} /><span className="fake-check"><Check size={12} /></span>{family}</label>)}</div></div>
          <div className="form-grid"><label className="field"><span>Seniority</span><select value={profile.seniority} onChange={(event) => onChange({ ...profile, seniority: event.target.value })}><option value="any">Any / not specified</option><option value="Entry-level">Entry level</option><option value="Junior">Junior</option><option value="Mid-level">Mid-level</option><option value="Senior">Senior</option><option value="Lead">Lead / principal</option></select></label><label className="field"><span>Preferred work mode</span><select value={profile.remotePreference} onChange={(event) => onChange({ ...profile, remotePreference: event.target.value as CandidateProfile['remotePreference'] })}><option value="any">Any</option><option value="remote">Remote</option><option value="hybrid">Hybrid</option><option value="onsite">On-site</option></select></label></div>
        </section>
        <section className="form-section"><div className="form-section-heading"><div className="step-number">03</div><div><h2>Where you can work</h2><p>Only select countries where you have, or expect to have, work eligibility. This is used for filtering, not legal advice.</p></div></div>
          <label className="field country-search"><span>Find countries <small>Search by name or ISO code</small></span><input value={countryQuery} onChange={(event) => setCountryQuery(event.target.value)} placeholder="e.g. Nigeria or NG" aria-label="Search countries where you can work" autoComplete="off" /></label>
          <div className="selected-country-area" aria-live="polite"><div className="country-results-heading">Selected work-eligible countries ({selectedCountries.length})</div>{selectedCountries.length > 0 ? <div className="selected-country-chips">{selectedCountries.map(([code, name]) => <span className="selected-country-chip" key={code}>{name}<button type="button" aria-label={`Remove ${name}`} onClick={() => onCountryToggle(code)}><X size={12} /></button></span>)}</div> : <p className="country-empty">None selected. Regional eligibility will stay unknown until you add a country.</p>}</div>
          {normalizedCountryQuery && <div className="country-search-results"><div className="country-results-heading">Matches for “{countryQuery.trim()}”</div>{countriesToShow.length > 0 ? <><div className="country-grid">{countriesToShow.map(([code, label]) => <label key={code} className={`country-check ${profile.workCountries.includes(code) ? 'country-checked' : ''}`}><input type="checkbox" checked={profile.workCountries.includes(code)} onChange={() => onCountryToggle(code)} /><span className="fake-check"><Check size={12} /></span><span>{label}</span></label>)}</div>{matchingCountries.length > countriesToShow.length && <p className="country-hint">Showing the first 12 matches; type more to narrow the list.</p>}</> : <p className="country-empty">No match found. Try the country name or its two-letter ISO code.</p>}</div>}
        </section>
        <section className="form-section"><div className="form-section-heading"><div className="step-number">04</div><div><h2>Salary display</h2><p>Amounts are shown in the selected currency when a current reference rate is available.</p></div></div>
          <label className="field currency-preference"><span>Display currency</span><select value={profile.preferredCurrency} onChange={(event) => onChange({ ...profile, preferredCurrency: event.target.value })}>{CURRENCY_OPTIONS.map((currency) => <option key={currency}>{currency}</option>)}</select></label>
        </section>
        <section className="form-section cv-section"><div className="form-section-heading"><div className="step-number">05</div><div><h2>CV import <span className="optional-label">OPTIONAL</span></h2><p>Upload a PDF, DOCX or TXT. The file is read in this browser; only extracted text is sent for profile suggestions.</p></div></div>
          <label className={`upload-zone ${cvBusy ? 'upload-busy' : ''}`}><input type="file" accept=".pdf,.docx,.txt,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain" onChange={onFile} disabled={cvBusy} /><div className="upload-icon">{cvBusy ? <LoaderCircle size={20} className="spin" /> : <Upload size={20} />}</div><div><strong>{cvBusy ? 'Reading your CV…' : 'Choose a CV to review'}</strong><span>PDF, DOCX or TXT · up to 5 MB · scanned PDFs not supported in this preview</span></div><span className="upload-button">Browse files</span></label>
          {cvFileName && !cvBusy && !cvDraft && !cvError && <p className="muted-inline"><FileText size={14} /> {cvFileName}</p>}
          {cvError && <div className="inline-error" role="alert"><CircleAlert size={16} />{cvError}</div>}
          {cvDraft && <div className="cv-review" aria-live="polite"><div className="cv-review-head"><div><span className="eyebrow">REVIEW BEFORE SAVING</span><h3>Suggestions from {cvFileName || 'your CV'}</h3></div><button className="icon-button" type="button" onClick={onDiscardCv} aria-label="Discard CV suggestions"><X size={17} /></button></div><p className="ai-note"><Sparkles size={15} />{aiAvailable && cvDraft.extractionMode === 'workers-ai' ? 'AI extraction was used. These are suggestions, not verified facts.' : 'Local keyword extraction was used in this preview. These are suggestions, not verified facts.'}</p><label className="field"><span>Name suggestion</span><input value={cvDraft.displayName} onChange={(event) => onDraftChange({ ...cvDraft, displayName: event.target.value })} /></label><label className="field"><span>Skill suggestions <small>Edit the list before adding</small></span><textarea rows={3} value={cvDraft.skills.join(', ')} onChange={(event) => onDraftChange({ ...cvDraft, skills: event.target.value.split(',').map((item) => item.trim()).filter(Boolean) })} /></label><label className="field"><span>Possible role families <small>May be incomplete</small></span><textarea rows={2} value={cvDraft.targetRoles.join(', ')} onChange={(event) => onDraftChange({ ...cvDraft, targetRoles: event.target.value.split(',').map((item) => item.trim()).filter(Boolean) })} /></label><div className="cv-actions"><button type="button" className="button-primary" onClick={onApplyCv}><Check size={16} /> Add to profile draft</button><button type="button" className="text-button" onClick={onDiscardCv}>Discard</button></div></div>}
          <p className="privacy-footnote"><ShieldCheck size={14} />No raw CV is saved by this preview. Confirmed skills are stored in this browser only.</p>
        </section>
        <div className="form-actions"><button type="submit" className="button-primary"><Check size={16} /> Save Skill Passport</button><span>Preview data is stored on this device, not in a live account.</span></div>
      </form>
    </div>
  )
}

function AlertsPage({ preferences, onChange, telegramConfigured, botUsername, onSave }: {
  preferences: AlertPreferences; onChange: <K extends keyof AlertPreferences>(key: K, value: AlertPreferences[K]) => void;
  telegramConfigured: boolean; botUsername: string | null; onSave: () => void;
}) {
  return (
    <div className="subpage">
      <div className="page-heading-row compact-heading"><div><p className="eyebrow">ONE CHANNEL · YOUR PACE</p><h1>Telegram alerts</h1><p className="page-intro">Choose when matching roles should reach you. We will not send messages until you connect the bot.</p></div></div>
      <div className="settings-layout"><section className="settings-main">
        <div className="setting-block"><div className="setting-heading"><div className="telegram-symbol"><Send size={19} /></div><div><h2>Connect your Telegram</h2><p>{telegramConfigured && botUsername ? `Bot @${botUsername} is configured; account linking still needs to be completed.` : 'The bot is not configured in this preview. No messages can be sent yet.'}</p></div><span className={`connection-pill ${telegramConfigured ? 'connected' : 'not-connected'}`}><span />{telegramConfigured ? 'Bot ready' : 'Not connected'}</span></div>{telegramConfigured && botUsername ? <a className="button-secondary" href={`https://t.me/${botUsername}`} target="_blank" rel="noreferrer">Open Telegram bot <ArrowUpRight size={15} /></a> : <div className="setup-notice"><LockKeyhole size={16} /><span>Live alerts need a bot username, a secret bot token and a deployed webhook. None are configured here.</span></div>}</div>
        <div className="setting-block"><div className="setting-heading"><div className="setting-symbol"><Bell size={18} /></div><div><h2>Alert schedule</h2><p>Only qualifying jobs should be sent; you can change this any time.</p></div></div><label className="toggle-row"><span><strong>Enable Telegram alerts</strong><small>Requires a linked Telegram account and active paid access.</small></span><input type="checkbox" checked={preferences.enabled} onChange={(event) => onChange('enabled', event.target.checked)} /><span className="toggle-track" /></label><div className="form-grid"><label className="field"><span>Delivery</span><select value={preferences.digest} onChange={(event) => onChange('digest', event.target.value as AlertPreferences['digest'])}><option value="immediate">As soon as detected</option><option value="daily">Daily digest</option></select></label><label className="field"><span>Minimum match score</span><select value={preferences.minimumScore} onChange={(event) => onChange('minimumScore', Number(event.target.value))}><option value={55}>55% — more results</option><option value={65}>65% — balanced</option><option value={75}>75% — fewer, tighter matches</option><option value={85}>85% — high precision</option></select></label></div><div className="form-grid quiet-hours"><label className="field"><span>Quiet hours start</span><input type="time" value={preferences.quietStart} onChange={(event) => onChange('quietStart', event.target.value)} /></label><label className="field"><span>Quiet hours end</span><input type="time" value={preferences.quietEnd} onChange={(event) => onChange('quietEnd', event.target.value)} /></label></div></div>
        <button className="button-primary" onClick={onSave}><Check size={16} /> Save alert preferences</button>
      </section><aside className="settings-aside"><div className="aside-illustration"><div className="signal-bars"><i /><i /><i /><i /><i /></div><div className="signal-orbit"><Bell size={20} /></div></div><h3>A good alert is worth opening.</h3><p>We should send a role only after checking that it is new to you, relevant to your profile and not already delivered through another channel.</p><ul className="plain-check-list"><li><Check size={14} />Duplicate suppression</li><li><Check size={14} />Quiet hours and digest control</li><li><Check size={14} />One-tap stop and account deletion</li></ul></aside></div>
    </div>
  )
}

function AccountPage({ demoAccess, onToggleDemo }: { demoAccess: boolean; onToggleDemo: () => void }) {
  return (
    <div className="subpage">
      <div className="page-heading-row compact-heading"><div><p className="eyebrow">TRANSPARENT ACCESS</p><h1>Plan & access</h1><p className="page-intro">The proposed price is shown for planning. This preview does not take payment or activate a real subscription.</p></div></div>
      <div className="billing-layout"><section className="billing-main"><div className="plan-heading"><div><span className="eyebrow">PROPOSED MEMBER PLAN</span><h2>Role Signal Plus</h2><p>Personalised discovery, eligibility context and Telegram alerts.</p></div><div className="plan-price"><strong>₦10,000</strong><span>billing period to be confirmed · proposed</span></div></div><ul className="plan-inclusions"><li><Check size={16} />Global tech opportunity feed from permitted sources</li><li><Check size={16} />Skill-based matching with visible reasons and gaps</li><li><Check size={16} />Location and work-eligibility signals, including unknowns</li><li><Check size={16} />Telegram alerts after bot setup and opt-in</li><li><Check size={16} />Saved roles and application tracking</li></ul><div className="payment-pending"><WalletCards size={17} /><div><strong>Checkout is not configured</strong><span>A payment provider must be selected and connected before real subscriptions can be activated. No card or bank details are collected here.</span></div></div><div className="preview-entitlement"><div><span className={`connection-pill ${demoAccess ? 'connected' : 'not-connected'}`}><span />{demoAccess ? 'Preview access enabled' : 'No subscription in preview'}</span><p>This local toggle is only for testing the interface. It does not charge money or unlock a production account.</p></div><button className="button-secondary" onClick={onToggleDemo}>{demoAccess ? 'Turn off preview access' : 'Enable preview access'}</button></div></section><aside className="billing-aside"><ShieldCheck size={20} /><h3>Pay for the service, not the application.</h3><p>Any real subscription should buy matching and alert services. Applying to an employer’s job remains between the candidate and the employer.</p><div className="billing-fineprint">Global pricing, tax treatment, payment fees, cancellation and refund terms still need to be decided before launch.</div></aside></div>
    </div>
  )
}

function EmptyState({ icon: Icon, title, body, action, onAction }: { icon: typeof Search; title: string; body: string; action: string; onAction: () => void }) {
  return <div className="empty-state"><div className="empty-icon"><Icon size={21} /></div><h2>{title}</h2><p>{body}</p><button className="button-secondary" onClick={onAction}>{action} <ArrowRight size={15} /></button></div>
}

function MobileNav({ page, onNavigate }: { page: Page; onNavigate: (page: Page) => void }) {
  const items = navItems.filter((item) => ['discover', 'saved', 'applications', 'profile'].includes(item.id))
  return <nav className="mobile-nav" aria-label="Mobile navigation">{items.map(({ id, label, icon: Icon }) => <button key={id} className={page === id ? 'mobile-nav-active' : ''} onClick={() => onNavigate(id)} aria-current={page === id ? 'page' : undefined}><Icon size={19} /><span>{label === 'Discover' ? 'Jobs' : label === 'Applications' ? 'Applied' : label === 'Skill Passport' ? 'Profile' : 'Saved'}</span></button>)}<button className={page === 'alerts' ? 'mobile-nav-active' : ''} onClick={() => onNavigate('alerts')} aria-current={page === 'alerts' ? 'page' : undefined}><Bell size={19} /><span>Alerts</span></button></nav>
}

function familySlug(family: string) {
  return family.toLowerCase().replace(/[^a-z0-9]+/g, '-')
}

function capitalize(value: string) { return value.charAt(0).toUpperCase() + value.slice(1) }

export default App
