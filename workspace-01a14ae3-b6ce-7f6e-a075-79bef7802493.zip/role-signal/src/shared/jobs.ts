export type Eligibility = 'eligible' | 'restricted' | 'unknown'
export type WorkMode = 'remote' | 'hybrid' | 'onsite' | 'unknown'

export type Job = {
  id: string
  employer: string
  title: string
  description: string
  family: string
  seniority: string
  location: string
  countryCode: string | null
  workMode: WorkMode
  eligibleCountries: string[]
  eligibility: Eligibility
  sponsorship: 'yes' | 'no' | 'unknown'
  employment: string
  salaryMin: number | null
  salaryMax: number | null
  salaryCurrency: string | null
  salaryPeriod: string | null
  requiredSkills: string[]
  preferredSkills: string[]
  source: string
  sourceUrl: string | null
  postedAt: string
  firstSeenAt: string
  lastVerifiedAt: string | null
  status: 'active' | 'possibly_expired' | 'expired' | 'under_review'
  isDemo: boolean
}

export type CandidateProfile = {
  displayName: string
  workCountries: string[]
  skills: string[]
  targetRoles: string[]
  seniority: string
  remotePreference: 'any' | 'remote' | 'hybrid' | 'onsite'
  preferredCurrency: string
}

export const DEFAULT_PROFILE: CandidateProfile = {
  displayName: '',
  workCountries: [],
  skills: [],
  targetRoles: [],
  seniority: 'any',
  remotePreference: 'any',
  preferredCurrency: 'USD',
}

// Clearly fictional preview records. These must never be represented as live vacancies.
export const DEMO_JOBS: Job[] = [
  {
    id: 'demo-platform', employer: 'Example Systems (demo)', title: 'Platform Engineer',
    description: 'A sample platform role for previewing the matching experience. This is fictional demo content, not a live vacancy. The example requirements include infrastructure as code, Linux operations and observability.',
    family: 'Cloud & platform', seniority: 'Mid-level', location: 'Remote · eligible countries unknown', countryCode: null,
    workMode: 'remote', eligibleCountries: [], eligibility: 'unknown', sponsorship: 'unknown', employment: 'Full-time',
    salaryMin: 98000, salaryMax: 135000, salaryCurrency: 'USD', salaryPeriod: 'year',
    requiredSkills: ['Kubernetes', 'Terraform', 'Linux', 'AWS'], preferredSkills: ['Python', 'Observability'],
    source: 'Preview sample dataset', sourceUrl: null, postedAt: '2026-10-15T09:00:00Z', firstSeenAt: '2026-10-16T10:00:00Z', lastVerifiedAt: '2026-10-16T10:00:00Z', status: 'active', isDemo: true,
  },
  {
    id: 'demo-cyber', employer: 'Northstar Example (demo)', title: 'Security Operations Analyst',
    description: 'A sample security operations role. Work-authorisation requirements are intentionally shown as unknown in this preview.',
    family: 'Cybersecurity', seniority: 'Entry-level', location: 'Hybrid · Dublin, Ireland', countryCode: 'IE',
    workMode: 'hybrid', eligibleCountries: ['IE'], eligibility: 'unknown', sponsorship: 'unknown', employment: 'Full-time',
    salaryMin: 42000, salaryMax: 56000, salaryCurrency: 'EUR', salaryPeriod: 'year',
    requiredSkills: ['SIEM', 'Incident response', 'Networking'], preferredSkills: ['Linux', 'Python'],
    source: 'Preview sample dataset', sourceUrl: null, postedAt: '2026-10-14T12:30:00Z', firstSeenAt: '2026-10-15T08:30:00Z', lastVerifiedAt: '2026-10-15T08:30:00Z', status: 'active', isDemo: true,
  },
  {
    id: 'demo-data', employer: 'Fieldwork Labs (demo)', title: 'Data Analyst',
    description: 'A sample analytics role for demonstrating skill-based relevance and salary currency controls. This is not a live opening.',
    family: 'Data & AI', seniority: 'Mid-level', location: 'Remote · worldwide eligibility not verified', countryCode: null,
    workMode: 'remote', eligibleCountries: [], eligibility: 'unknown', sponsorship: 'unknown', employment: 'Full-time',
    salaryMin: 52000, salaryMax: 72000, salaryCurrency: 'GBP', salaryPeriod: 'year',
    requiredSkills: ['SQL', 'Python', 'Data visualisation'], preferredSkills: ['dbt', 'Statistics'],
    source: 'Preview sample dataset', sourceUrl: null, postedAt: '2026-10-13T08:00:00Z', firstSeenAt: '2026-10-14T07:00:00Z', lastVerifiedAt: '2026-10-14T07:00:00Z', status: 'active', isDemo: true,
  },
  {
    id: 'demo-product', employer: 'Plainview Product Co. (demo)', title: 'Product Designer',
    description: 'A sample product design role. Example listing only; the employer and vacancy are fictional.',
    family: 'Product & design', seniority: 'Mid-level', location: 'On-site · Amsterdam, Netherlands', countryCode: 'NL',
    workMode: 'onsite', eligibleCountries: ['NL'], eligibility: 'unknown', sponsorship: 'unknown', employment: 'Full-time',
    salaryMin: 54000, salaryMax: 69000, salaryCurrency: 'EUR', salaryPeriod: 'year',
    requiredSkills: ['Product design', 'Figma', 'User research'], preferredSkills: ['Accessibility', 'Prototyping'],
    source: 'Preview sample dataset', sourceUrl: null, postedAt: '2026-10-12T16:45:00Z', firstSeenAt: '2026-10-13T09:10:00Z', lastVerifiedAt: '2026-10-13T09:10:00Z', status: 'active', isDemo: true,
  },
  {
    id: 'demo-support', employer: 'Example Cloud Services (demo)', title: 'Technical Support Engineer',
    description: 'A sample customer-facing technical role, included to demonstrate that the platform is not limited to software developers.',
    family: 'IT & technical operations', seniority: 'Entry-level', location: 'Remote · North America only (demo)', countryCode: 'US',
    workMode: 'remote', eligibleCountries: ['US', 'CA'], eligibility: 'restricted', sponsorship: 'no', employment: 'Full-time',
    salaryMin: 64000, salaryMax: 82000, salaryCurrency: 'USD', salaryPeriod: 'year',
    requiredSkills: ['Linux', 'Networking', 'Troubleshooting'], preferredSkills: ['SQL', 'Customer support'],
    source: 'Preview sample dataset', sourceUrl: null, postedAt: '2026-10-11T11:15:00Z', firstSeenAt: '2026-10-12T11:20:00Z', lastVerifiedAt: '2026-10-12T11:20:00Z', status: 'active', isDemo: true,
  },
  {
    id: 'demo-qa', employer: 'Testbench Studio (demo)', title: 'QA Automation Engineer',
    description: 'A sample quality engineering role with test automation and release-quality responsibilities.',
    family: 'Quality engineering', seniority: 'Mid-level', location: 'Remote · eligibility not stated', countryCode: null,
    workMode: 'remote', eligibleCountries: [], eligibility: 'unknown', sponsorship: 'unknown', employment: 'Contract',
    salaryMin: 65, salaryMax: 90, salaryCurrency: 'USD', salaryPeriod: 'hour',
    requiredSkills: ['Playwright', 'API testing', 'JavaScript'], preferredSkills: ['CI/CD', 'Accessibility testing'],
    source: 'Preview sample dataset', sourceUrl: null, postedAt: '2026-10-10T10:00:00Z', firstSeenAt: '2026-10-11T09:00:00Z', lastVerifiedAt: '2026-10-11T09:00:00Z', status: 'active', isDemo: true,
  },
  {
    id: 'demo-software', employer: 'Cedar Works (demo)', title: 'Software Engineer',
    description: 'A fictional role demonstrating a conventional software engineering listing alongside other technology disciplines.',
    family: 'Software engineering', seniority: 'Junior', location: 'Remote · hiring countries not stated', countryCode: null,
    workMode: 'remote', eligibleCountries: [], eligibility: 'unknown', sponsorship: 'unknown', employment: 'Full-time',
    salaryMin: 72000, salaryMax: 96000, salaryCurrency: 'USD', salaryPeriod: 'year',
    requiredSkills: ['TypeScript', 'React', 'API design'], preferredSkills: ['Testing', 'Accessibility'],
    source: 'Preview sample dataset', sourceUrl: null, postedAt: '2026-10-09T08:00:00Z', firstSeenAt: '2026-10-10T08:00:00Z', lastVerifiedAt: '2026-10-10T08:00:00Z', status: 'active', isDemo: true,
  },
  {
    id: 'demo-solutions', employer: 'Atlas Example Software (demo)', title: 'Solutions Engineer',
    description: 'A fictional technical customer-facing role with product demonstrations, integration guidance and technical writing responsibilities.',
    family: 'Technical sales & writing', seniority: 'Mid-level', location: 'Hybrid · Toronto, Canada', countryCode: 'CA',
    workMode: 'hybrid', eligibleCountries: ['CA'], eligibility: 'unknown', sponsorship: 'unknown', employment: 'Full-time',
    salaryMin: 85000, salaryMax: 112000, salaryCurrency: 'CAD', salaryPeriod: 'year',
    requiredSkills: ['API design', 'Technical communication', 'Customer discovery'], preferredSkills: ['TypeScript', 'Cloud platforms'],
    source: 'Preview sample dataset', sourceUrl: null, postedAt: '2026-10-08T14:00:00Z', firstSeenAt: '2026-10-09T09:00:00Z', lastVerifiedAt: '2026-10-09T09:00:00Z', status: 'active', isDemo: true,
  },
]
