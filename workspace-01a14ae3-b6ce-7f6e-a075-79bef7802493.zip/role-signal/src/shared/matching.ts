import type { CandidateProfile, Job } from './jobs'

export type MatchResult = {
  score: number | null
  eligibility: 'eligible' | 'restricted' | 'unknown'
  eligibilityReason: string
  matchedSkills: string[]
  missingRequired: string[]
  reasons: string[]
}

const norm = (value: string) => value.toLowerCase().trim().replace(/[^a-z0-9+#.]/g, '')
const aliases: Record<string, string[]> = {
  js: ['javascript'], javascript: ['js'], ts: ['typescript'], typescript: ['ts'],
  k8s: ['kubernetes'], kubernetes: ['k8s'], postgres: ['postgresql'], postgresql: ['postgres'],
  'amazon web services': ['aws'], aws: ['amazon web services'], 'google cloud': ['gcp'], gcp: ['google cloud'],
  'user experience': ['ux'], 'user experience design': ['ux design'], 'ux design': ['user experience design'],
  'quality assurance': ['qa'], qa: ['quality assurance'], 'site reliability engineering': ['sre'], sre: ['site reliability engineering'],
  'information security': ['cybersecurity'], cybersecurity: ['information security'],
}

function skillMatch(a: string, b: string): boolean {
  const left = norm(a)
  const right = norm(b)
  if (!left || !right) return false
  if (left === right) return true
  return (aliases[left] ?? []).some((alias) => norm(alias) === right)
}

export function matchJob(job: Job, profile: CandidateProfile): MatchResult {
  const allowed = new Set(profile.workCountries.map((country) => country.toUpperCase()))
  let eligibility: MatchResult['eligibility'] = 'unknown'
  let eligibilityReason = 'The employer’s eligible hiring locations are not confirmed.'

  if (job.eligibleCountries.length > 0) {
    if (allowed.size === 0) {
      eligibility = 'unknown'
      eligibilityReason = `The listing names ${job.eligibleCountries.join(', ')}, but your work-eligibility profile is blank. Add eligible countries to check for overlap.`
    } else {
      const overlap = job.eligibleCountries.some((country) => allowed.has(country.toUpperCase()))
      eligibility = overlap ? 'eligible' : 'restricted'
      eligibilityReason = overlap
        ? `Your stated work eligibility overlaps with ${job.eligibleCountries.join(', ')}.`
        : `The listing names ${job.eligibleCountries.join(', ')}; your profile does not currently include one of those countries.`
    }
  } else if (job.countryCode && allowed.size > 0 && allowed.has(job.countryCode.toUpperCase())) {
    eligibility = 'eligible'
    eligibilityReason = `Your stated work eligibility includes ${job.countryCode}.`
  } else if (job.eligibility === 'eligible') {
    if (allowed.size === 0) {
      eligibility = 'unknown'
      eligibilityReason = 'The listing marks this role as open, but your work-eligibility profile is blank; confirm the employer’s criteria.'
    } else {
      eligibility = 'eligible'
      eligibilityReason = 'The source marks this role as open to your selected location; confirm the employer’s criteria.'
    }
  } else if (job.eligibility === 'restricted') {
    eligibility = 'unknown'
    eligibilityReason = 'The listing signals a geographic restriction but does not identify eligible countries, so a profile-based check is not possible.'
  }

  const profileSkills = profile.skills.filter(Boolean)
  if (profileSkills.length === 0) {
    return { score: null, eligibility, eligibilityReason, matchedSkills: [], missingRequired: job.requiredSkills, reasons: ['Add skills to your Skill Passport to calculate a useful match score.'] }
  }

  const matchedSkills = job.requiredSkills.filter((required) => profileSkills.some((skill) => skillMatch(skill, required)))
  const matchedPreferred = job.preferredSkills.filter((preferred) => profileSkills.some((skill) => skillMatch(skill, preferred)))
  const missingRequired = job.requiredSkills.filter((required) => !matchedSkills.includes(required))

  const requiredPart = job.requiredSkills.length ? (matchedSkills.length / job.requiredSkills.length) * 48 : 24
  const preferredPart = job.preferredSkills.length ? (matchedPreferred.length / job.preferredSkills.length) * 14 : 7
  const roleMatches = profile.targetRoles.some((role) => role === job.family || role === job.title)
  const roleKnown = job.family !== 'Other technology'
  const rolePart = profile.targetRoles.length === 0 || (!roleKnown && !roleMatches) ? 9 : roleMatches ? 18 : 5
  const seniorityMatches = profile.seniority === 'any' || profile.seniority === job.seniority
  const seniorityKnown = job.seniority !== 'Not specified'
  const seniorityPart = profile.seniority === 'any' || !seniorityKnown ? 5 : seniorityMatches ? 10 : 4
  const modeMatches = profile.remotePreference === 'any' || profile.remotePreference === job.workMode
  const modePart = profile.remotePreference === 'any' || job.workMode === 'unknown' ? 5 : modeMatches ? 10 : 2
  const score = Math.max(0, Math.min(100, Math.round(requiredPart + preferredPart + rolePart + seniorityPart + modePart)))

  const reasons: string[] = []
  if (job.requiredSkills.length > 0) reasons.push(`${matchedSkills.length} of ${job.requiredSkills.length} listed required skills match your profile.`)
  else reasons.push('The listing does not specify required skills; this score component is neutral.')
  if (job.preferredSkills.length > 0) reasons.push(`${matchedPreferred.length} of ${job.preferredSkills.length} listed useful skills match your profile.`)
  if (profile.targetRoles.length > 0 && roleKnown) reasons.push(roleMatches ? 'The role family matches one of your targets.' : 'The role family is outside your selected targets.')
  else reasons.push('No target-role or usable role-family detail; this score component is neutral.')
  if (profile.seniority !== 'any' && seniorityKnown) reasons.push(seniorityMatches ? `The listed ${job.seniority} level matches your preference.` : `The listed ${job.seniority} level differs from your ${profile.seniority} preference.`)
  if (profile.remotePreference !== 'any' && job.workMode !== 'unknown') reasons.push(modeMatches ? `The ${job.workMode} arrangement matches your preference.` : `The listing’s ${job.workMode} arrangement differs from your preference.`)
  if (!reasons.length) reasons.push('Review the listing and profile details before applying.')

  return { score, eligibility, eligibilityReason, matchedSkills, missingRequired, reasons }
}

export function convertSalary(amount: number, from: string, to: string, rates: Record<string, number>): number | null {
  const source = from.toUpperCase()
  const target = to.toUpperCase()
  if (source === target) return amount
  // Rates are expressed as units of quote currency per one unit of base currency.
  const sourcePerUsd = rates[source]
  const targetPerUsd = rates[target]
  if (!sourcePerUsd || !targetPerUsd) return null
  return amount / sourcePerUsd * targetPerUsd
}
