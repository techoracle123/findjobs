import * as pdfjs from 'pdfjs-dist'
import pdfWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url'
import { unzipSync } from 'fflate'

pdfjs.GlobalWorkerOptions.workerSrc = pdfWorkerUrl

export type CVTextResult = { text: string; pages?: number }

export async function extractCVText(file: File): Promise<CVTextResult> {
  const extension = file.name.toLowerCase().split('.').pop()
  if (file.size > 5 * 1024 * 1024) throw new Error('Keep CV files under 5 MB for this free preview.')
  if (extension === 'txt') return { text: await file.text() }

  if (extension === 'pdf' || file.type === 'application/pdf') {
    const data = new Uint8Array(await file.arrayBuffer())
    const pdf = await pdfjs.getDocument({ data }).promise
    const pages: string[] = []
    for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
      const page = await pdf.getPage(pageNumber)
      const content = await page.getTextContent()
      pages.push(content.items.map((item) => ('str' in item ? item.str : '')).join(' '))
    }
    return { text: pages.join('\n'), pages: pdf.numPages }
  }

  if (extension === 'docx' || file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
    const archive = unzipSync(new Uint8Array(await file.arrayBuffer()))
    const documentXml = archive['word/document.xml']
    if (!documentXml) throw new Error('This DOCX does not contain a readable document body.')
    const parsed = new DOMParser().parseFromString(new TextDecoder().decode(documentXml), 'application/xml')
    if (parsed.getElementsByTagName('parsererror').length) throw new Error('The DOCX document could not be read.')
    const textNodes = Array.from(parsed.getElementsByTagNameNS('http://schemas.openxmlformats.org/wordprocessingml/2006/main', 't'))
    return { text: textNodes.map((node) => node.textContent ?? '').join(' ') }
  }

  throw new Error('Please upload a PDF, DOCX or TXT CV. Scanned/image-only PDFs are not supported in this preview.')
}
