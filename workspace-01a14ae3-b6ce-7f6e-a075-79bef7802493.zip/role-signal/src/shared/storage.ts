import { DEFAULT_PROFILE, type CandidateProfile } from './jobs'

export type ApplicationState = Record<string, { status: string; note: string; updatedAt: string }>
export type AlertPreferences = { enabled: boolean; digest: 'immediate' | 'daily'; quietStart: string; quietEnd: string; minimumScore: number }

const keys = {
  profile: 'rolesignal.profile.v1',
  saved: 'rolesignal.saved.v1',
  applications: 'rolesignal.applications.v1',
  alerts: 'rolesignal.alerts.v1',
  demoAccess: 'rolesignal.demo-access.v1',
}

export function loadValue<T>(key: keyof typeof keys, fallback: T): T {
  try {
    const raw = localStorage.getItem(keys[key])
    return raw ? { ...fallback as object, ...JSON.parse(raw) } as T : fallback
  } catch { return fallback }
}

export function saveValue<T>(key: keyof typeof keys, value: T) {
  try { localStorage.setItem(keys[key], JSON.stringify(value)) } catch { /* Private browsing can block storage. */ }
}

export const loadProfile = () => loadValue<CandidateProfile>('profile', DEFAULT_PROFILE)
export const saveProfile = (profile: CandidateProfile) => saveValue('profile', profile)
export const loadSaved = () => {
  try { return JSON.parse(localStorage.getItem(keys.saved) ?? '[]') as string[] } catch { return [] }
}
export const saveSaved = (value: string[]) => saveValue('saved', value)
export const loadApplications = () => loadValue<ApplicationState>('applications', {})
export const saveApplications = (value: ApplicationState) => saveValue('applications', value)
export const loadAlerts = () => loadValue<AlertPreferences>('alerts', { enabled: false, digest: 'daily', quietStart: '22:00', quietEnd: '08:00', minimumScore: 70 })
export const saveAlerts = (value: AlertPreferences) => saveValue('alerts', value)
export const loadDemoAccess = () => localStorage.getItem(keys.demoAccess) === 'true'
export const saveDemoAccess = (value: boolean) => { try { localStorage.setItem(keys.demoAccess, String(value)) } catch { /* optional */ } }
