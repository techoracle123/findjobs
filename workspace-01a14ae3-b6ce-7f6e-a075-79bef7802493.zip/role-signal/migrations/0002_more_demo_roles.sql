INSERT OR IGNORE INTO jobs (
  id, source_id, external_id, employer_name, title, description, role_family, seniority,
  location_label, country_code, remote_type, eligible_countries_json, eligibility_status,
  sponsorship_status, employment_type, salary_min, salary_max, salary_currency,
  salary_period, salary_source, required_skills_json, preferred_skills_json,
  posted_at, first_seen_at, last_verified_at, status, is_demo
) VALUES
('demo-software', 'demo-source', 'demo-software', 'Cedar Works (demo)', 'Software Engineer', 'A fictional role demonstrating a conventional software engineering listing alongside other technology disciplines.', 'Software engineering', 'Junior', 'Remote · hiring countries not stated', NULL, 'remote', '[]', 'unknown', 'unknown', 'Full-time', 72000, 96000, 'USD', 'year', 'Demo figure only', '["TypeScript","React","API design"]', '["Testing","Accessibility"]', '2026-10-09T08:00:00Z', '2026-10-10T08:00:00Z', '2026-10-10T08:00:00Z', 'active', 1),
('demo-solutions', 'demo-source', 'demo-solutions', 'Atlas Example Software (demo)', 'Solutions Engineer', 'A fictional technical customer-facing role with product demonstrations, integration guidance and technical writing responsibilities.', 'Technical sales & writing', 'Mid-level', 'Hybrid · Toronto, Canada', 'CA', 'hybrid', '["CA"]', 'unknown', 'unknown', 'Full-time', 85000, 112000, 'CAD', 'year', 'Demo figure only', '["API design","Technical communication","Customer discovery"]', '["TypeScript","Cloud platforms"]', '2026-10-08T14:00:00Z', '2026-10-09T09:00:00Z', '2026-10-09T09:00:00Z', 'active', 1);
