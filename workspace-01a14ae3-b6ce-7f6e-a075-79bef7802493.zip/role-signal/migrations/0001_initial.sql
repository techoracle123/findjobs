PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS job_sources (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  source_type TEXT NOT NULL CHECK (source_type IN ('ats_api','employer_feed','partner','manual','demo')),
  base_url TEXT,
  permission_status TEXT NOT NULL DEFAULT 'not_reviewed',
  health_status TEXT NOT NULL DEFAULT 'not_configured',
  last_checked_at TEXT,
  last_error TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS jobs (
  id TEXT PRIMARY KEY,
  source_id TEXT REFERENCES job_sources(id),
  external_id TEXT,
  canonical_url TEXT,
  employer_name TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  role_family TEXT NOT NULL DEFAULT 'Other technology',
  seniority TEXT NOT NULL DEFAULT 'Not specified',
  location_label TEXT NOT NULL DEFAULT 'Location not specified',
  country_code TEXT,
  remote_type TEXT NOT NULL DEFAULT 'unknown' CHECK (remote_type IN ('remote','hybrid','onsite','unknown')),
  eligible_countries_json TEXT NOT NULL DEFAULT '[]',
  eligibility_status TEXT NOT NULL DEFAULT 'unknown' CHECK (eligibility_status IN ('eligible','restricted','unknown')),
  sponsorship_status TEXT NOT NULL DEFAULT 'unknown' CHECK (sponsorship_status IN ('yes','no','unknown')),
  employment_type TEXT NOT NULL DEFAULT 'Not specified',
  salary_min REAL,
  salary_max REAL,
  salary_currency TEXT,
  salary_period TEXT,
  salary_source TEXT,
  required_skills_json TEXT NOT NULL DEFAULT '[]',
  preferred_skills_json TEXT NOT NULL DEFAULT '[]',
  posted_at TEXT,
  first_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_verified_at TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','possibly_expired','expired','under_review')),
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(source_id, external_id)
);

CREATE INDEX IF NOT EXISTS idx_jobs_status_posted ON jobs(status, posted_at DESC);
CREATE INDEX IF NOT EXISTS idx_jobs_role_family ON jobs(role_family, status);
CREATE INDEX IF NOT EXISTS idx_jobs_country ON jobs(country_code, status);
CREATE INDEX IF NOT EXISTS idx_jobs_seen ON jobs(first_seen_at DESC);

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  telegram_user_id TEXT UNIQUE,
  telegram_username TEXT,
  display_name TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT
);

CREATE TABLE IF NOT EXISTS profiles (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  home_country TEXT,
  allowed_work_countries_json TEXT NOT NULL DEFAULT '[]',
  preferred_job_countries_json TEXT NOT NULL DEFAULT '[]',
  skills_json TEXT NOT NULL DEFAULT '[]',
  target_roles_json TEXT NOT NULL DEFAULT '[]',
  seniority TEXT NOT NULL DEFAULT 'any',
  remote_preference TEXT NOT NULL DEFAULT 'any',
  preferred_currency TEXT NOT NULL DEFAULT 'USD',
  salary_floor REAL,
  salary_period TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cv_documents (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  object_key TEXT,
  filename TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  retention_status TEXT NOT NULL DEFAULT 'ephemeral',
  uploaded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT
);

CREATE TABLE IF NOT EXISTS saved_jobs (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  job_id TEXT NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, job_id)
);

CREATE TABLE IF NOT EXISTS applications (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  job_id TEXT NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'saved' CHECK (status IN ('saved','planning','applied','interview','offer','rejected','withdrawn')),
  private_notes TEXT NOT NULL DEFAULT '',
  applied_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, job_id)
);

CREATE TABLE IF NOT EXISTS notification_preferences (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  telegram_enabled INTEGER NOT NULL DEFAULT 0,
  daily_digest INTEGER NOT NULL DEFAULT 1,
  quiet_start TEXT NOT NULL DEFAULT '22:00',
  quiet_end TEXT NOT NULL DEFAULT '08:00',
  minimum_match_score INTEGER NOT NULL DEFAULT 65,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS subscriptions (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  provider TEXT,
  provider_customer_id TEXT,
  provider_subscription_id TEXT,
  status TEXT NOT NULL DEFAULT 'inactive' CHECK (status IN ('inactive','pending','active','past_due','cancelled','expired')),
  currency TEXT NOT NULL DEFAULT 'NGN',
  amount_minor INTEGER NOT NULL DEFAULT 1000000,
  current_period_end TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS notification_events (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  job_id TEXT NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  channel TEXT NOT NULL DEFAULT 'telegram',
  status TEXT NOT NULL DEFAULT 'queued',
  idempotency_key TEXT NOT NULL UNIQUE,
  attempted_at TEXT,
  delivered_at TEXT,
  error_code TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_feedback (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  job_id TEXT NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  feedback_type TEXT NOT NULL,
  note TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS audit_events (
  id TEXT PRIMARY KEY,
  actor_user_id TEXT,
  action TEXT NOT NULL,
  target_type TEXT NOT NULL,
  target_id TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT OR IGNORE INTO job_sources (id, name, source_type, permission_status, health_status)
VALUES ('demo-source', 'Preview sample dataset', 'demo', 'demo_only', 'demo');

INSERT OR IGNORE INTO jobs (
  id, source_id, external_id, employer_name, title, description, role_family, seniority,
  location_label, country_code, remote_type, eligible_countries_json, eligibility_status,
  sponsorship_status, employment_type, salary_min, salary_max, salary_currency,
  salary_period, salary_source, required_skills_json, preferred_skills_json,
  posted_at, first_seen_at, last_verified_at, status, is_demo
) VALUES
('demo-platform', 'demo-source', 'demo-platform', 'Example Systems (demo)', 'Platform Engineer', 'A sample platform role for previewing the matching experience. This is fictional demo content, not a live vacancy.', 'Cloud & platform', 'Mid-level', 'Remote · eligible countries unknown', NULL, 'remote', '[]', 'unknown', 'unknown', 'Full-time', 98000, 135000, 'USD', 'year', 'Demo figure only', '["Kubernetes","Terraform","Linux","AWS"]', '["Python","Observability"]', '2026-10-15T09:00:00Z', '2026-10-16T10:00:00Z', '2026-10-16T10:00:00Z', 'active', 1),
('demo-cyber', 'demo-source', 'demo-cyber', 'Northstar Example (demo)', 'Security Operations Analyst', 'A sample security operations role. Work-authorisation requirements are intentionally shown as unknown in this preview.', 'Cybersecurity', 'Entry-level', 'Hybrid · Dublin, Ireland', 'IE', 'hybrid', '["IE"]', 'unknown', 'unknown', 'Full-time', 42000, 56000, 'EUR', 'year', 'Demo figure only', '["SIEM","Incident response","Networking"]', '["Linux","Python"]', '2026-10-14T12:30:00Z', '2026-10-15T08:30:00Z', '2026-10-15T08:30:00Z', 'active', 1),
('demo-data', 'demo-source', 'demo-data', 'Fieldwork Labs (demo)', 'Data Analyst', 'A sample analytics role for demonstrating skill-based relevance and salary currency controls.', 'Data & AI', 'Mid-level', 'Remote · Worldwide eligibility not verified', NULL, 'remote', '[]', 'unknown', 'unknown', 'Full-time', 52000, 72000, 'GBP', 'year', 'Demo figure only', '["SQL","Python","Data visualisation"]', '["dbt","Statistics"]', '2026-10-13T08:00:00Z', '2026-10-14T07:00:00Z', '2026-10-14T07:00:00Z', 'active', 1),
('demo-product', 'demo-source', 'demo-product', 'Plainview Product Co. (demo)', 'Product Designer', 'A sample product design role. Example listing only; the employer and vacancy are fictional.', 'Product & design', 'Mid-level', 'On-site · Amsterdam, Netherlands', 'NL', 'onsite', '["NL"]', 'unknown', 'unknown', 'Full-time', 54000, 69000, 'EUR', 'year', 'Demo figure only', '["Product design","Figma","User research"]', '["Accessibility","Prototyping"]', '2026-10-12T16:45:00Z', '2026-10-13T09:10:00Z', '2026-10-13T09:10:00Z', 'active', 1),
('demo-support', 'demo-source', 'demo-support', 'Example Cloud Services (demo)', 'Technical Support Engineer', 'A sample customer-facing technical role, included to demonstrate that the platform is not limited to software developers.', 'IT & technical operations', 'Entry-level', 'Remote · North America only (demo)', 'US', 'remote', '["US","CA"]', 'restricted', 'no', 'Full-time', 64000, 82000, 'USD', 'year', 'Demo figure only', '["Linux","Networking","Troubleshooting"]', '["SQL","Customer support"]', '2026-10-11T11:15:00Z', '2026-10-12T11:20:00Z', '2026-10-12T11:20:00Z', 'active', 1),
('demo-qa', 'demo-source', 'demo-qa', 'Testbench Studio (demo)', 'QA Automation Engineer', 'A sample quality engineering role with test automation and release-quality responsibilities.', 'Quality engineering', 'Mid-level', 'Remote · eligibility not stated', NULL, 'remote', '[]', 'unknown', 'unknown', 'Contract', 65, 90, 'USD', 'hour', 'Demo figure only', '["Playwright","API testing","JavaScript"]', '["CI/CD","Accessibility testing"]', '2026-10-10T10:00:00Z', '2026-10-11T09:00:00Z', '2026-10-11T09:00:00Z', 'active', 1),
('demo-software', 'demo-source', 'demo-software', 'Cedar Works (demo)', 'Software Engineer', 'A fictional role demonstrating a conventional software engineering listing alongside other technology disciplines.', 'Software engineering', 'Junior', 'Remote · hiring countries not stated', NULL, 'remote', '[]', 'unknown', 'unknown', 'Full-time', 72000, 96000, 'USD', 'year', 'Demo figure only', '["TypeScript","React","API design"]', '["Testing","Accessibility"]', '2026-10-09T08:00:00Z', '2026-10-10T08:00:00Z', '2026-10-10T08:00:00Z', 'active', 1),
('demo-solutions', 'demo-source', 'demo-solutions', 'Atlas Example Software (demo)', 'Solutions Engineer', 'A fictional technical customer-facing role with product demonstrations, integration guidance and technical writing responsibilities.', 'Technical sales & writing', 'Mid-level', 'Hybrid · Toronto, Canada', 'CA', 'hybrid', '["CA"]', 'unknown', 'unknown', 'Full-time', 85000, 112000, 'CAD', 'year', 'Demo figure only', '["API design","Technical communication","Customer discovery"]', '["TypeScript","Cloud platforms"]', '2026-10-08T14:00:00Z', '2026-10-09T09:00:00Z', '2026-10-09T09:00:00Z', 'active', 1);
